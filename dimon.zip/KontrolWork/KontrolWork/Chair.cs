﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KontrolWork
{
    public class Chair
    {
        //    [Key]
        //    public int id { get; set; }
        //    [Required]
        //    public int number { get; set; }
        //    public int Hall { get; set; }
        //    public Tickets Ticket { get; set; }
        //}
    }
}
