﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KontrolWork
{
    internal class DatabaseContext : DbContext
    {
        public DbSet<Hall> Hall { get; set; }
        public DbSet<Chair> Chair { get; set; }
        public DbSet<Tickets> Ticket { get; set; }
        public DatabaseContext() { }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(Setting.SettingName);
        }
    }
}
