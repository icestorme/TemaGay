﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KontrolWork
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // Scaffold-DbContext "Server=PC-232-13\SQLExpress;Database=Cinema;Trusted_Connection=True;" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models
            //Scaffold-DbContext "Data Source=PC-232-13\SQLExpress;Initial Catalog=Cinema; User ID=U-19K;Password=19K$YcYO;Trusted_Connection=False" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models
        }

        private void First_Click(object sender, RoutedEventArgs e)
        {
            Stack4.Visibility = Visibility.Hidden;
            Stack3.Visibility = Visibility.Hidden;
            Stack2.Visibility = Visibility.Visible;
        }

        private void Second_Click(object sender, RoutedEventArgs e)
        {
            Stack2.Visibility = Visibility.Hidden;
            Stack3.Visibility = Visibility.Visible;
            Stack4.Visibility = Visibility.Hidden;
        }

        private void Third_Click(object sender, RoutedEventArgs e)
        {
            Stack2.Visibility = Visibility.Hidden;
            Stack3.Visibility = Visibility.Hidden;
            Stack4.Visibility = Visibility.Visible;
        }
        private void FirstSeans_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Seans1.IsEnabled = false;
        }
        private void SecondSeans_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Seans2.IsEnabled = false;
        }
        private void ThirdSeans_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Seans3.IsEnabled = false;
        }
        private void FourthSeans_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Seans4.IsEnabled = false;

        }
        private void FirstSeans1_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Seans11.IsEnabled = false;
        }
        private void SecondSeans2_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Seans22.IsEnabled = false;
        }
        private void ThirdSeans3_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Seans33.IsEnabled = false;
        }
        private void FourthSeans4_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Seans44.IsEnabled = false;
        }
        private void FifthSeans5_click(object sender,RoutedEventArgs e)
        {
            MessageBox.Show("Успешно");
            Seans55.IsEnabled = false;
        }
    }
}
