﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KontrolWork
{
    public static class Setting
    {
        public const string SettingName = @"Data source=PC-232-13\SQLEXPRESS;initial Catalog=CINEMA; User Id = U-19K;Password=19K$YcYO";
    }
}
