﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KontrolWork
{
    internal class Tickets
    {
       // [Key]
       // public int Id { get; set; }
       // [Required]
       // public string Cinema { get; set; }
        
       // public Hall Hall { get; set; }
 
       //[Required]
       // public Chair Chair { get; set; }
    }
}
